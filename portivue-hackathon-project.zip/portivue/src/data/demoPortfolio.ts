import { Profile, PortfolioEntry } from '../types/portfolio';

export const DEMO_PROFILE: Profile = {
  "id": "00000000-0000-0000-0000-000000000000",
  "full_name": "Ansh Shrivastava",
  "username": "ansh-shrivastava",
  "bio": "Computer science student passionate about web development, AI, and building useful digital products.",
  "skills": [
    "HTML",
    "CSS",
    "JavaScript",
    "React",
    "Python",
    "UI/UX Design"
  ],
  "avatar_url": null,
  "is_public": true,
  "created_at": "2025-01-15T10:00:00.000Z",
  "updated_at": "2025-02-10T14:30:00.000Z"
};

export const DEMO_ENTRIES: PortfolioEntry[] = [
  {
    "id": "demo-entry-1",
    "user_id": "00000000-0000-0000-0000-000000000000",
    "title": "Personal Portfolio Website",
    "description": "Designed and developed a responsive personal portfolio website using HTML, CSS, and JavaScript.",
    "category": "Projects",
    "evidence_url": "https://example.com/demo-portfolio/ansh-shrivastava-website",
    "evidence_type": "Live Deployment URL",
    "is_published": true,
    "created_at": "2025-01-20T09:00:00.000Z",
    "updated_at": "2025-01-20T09:00:00.000Z"
  },
  {
    "id": "demo-entry-2",
    "user_id": "00000000-0000-0000-0000-000000000000",
    "title": "AI Study Assistant",
    "description": "Built a student-focused study assistant prototype with AI-powered learning features.",
    "category": "Projects",
    "evidence_url": "https://example.com/demo-portfolio/ai-study-assistant-repo",
    "evidence_type": "GitHub Repository",
    "is_published": true,
    "created_at": "2025-01-28T11:30:00.000Z",
    "updated_at": "2025-01-28T11:30:00.000Z"
  },
  {
    "id": "demo-entry-3",
    "user_id": "00000000-0000-0000-0000-000000000000",
    "title": "Web Development Fundamentals",
    "description": "Completed a foundational web development learning program.",
    "category": "Certificates",
    "evidence_url": "https://example.com/demo-certificate/web-dev-fundamentals",
    "evidence_type": "Certificate Credential Link",
    "is_published": true,
    "created_at": "2025-02-02T15:00:00.000Z",
    "updated_at": "2025-02-02T15:00:00.000Z"
  },
  {
    "id": "demo-entry-4",
    "user_id": "00000000-0000-0000-0000-000000000000",
    "title": "Smart Campus Challenge",
    "description": "Participated in a student hackathon focused on improving campus experiences through technology.",
    "category": "Hackathons",
    "evidence_url": "https://example.com/demo-hackathon/smart-campus-challenge",
    "evidence_type": "Devpost / Hackathon Submission",
    "is_published": true,
    "created_at": "2025-02-09T18:20:00.000Z",
    "updated_at": "2025-02-09T18:20:00.000Z"
  }
];
