export interface GemmaAdapterConfig {
  enabled: boolean;
  model: 'gemma-4-2b-it' | 'gemma-4-9b-it';
  endpointUrl: string;
  sessionApiKey: string;
}

const promptResponseCache = new Map<string, string>();

export const formatTextDeterministically = (
  text: string,
  task: 'bio' | 'description'
): string => {
  const cleaned = text.replace(/\s+/g, ' ').trim();
  if (!cleaned) return '';
  const capitalized = cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
  return /[.!?]$/.test(capitalized) ? capitalized : `${capitalized}.`;
};

export async function runGemmaTextSuggestion(
  input: string,
  task: 'bio' | 'description',
  config: GemmaAdapterConfig
): Promise<{ text: string; source: 'gemma-4-cache' | 'gemma-4-live' | 'local-formatter' }> {
  const trimmed = input.trim();
  if (!trimmed) return { text: '', source: 'local-formatter' };

  const cacheKey = `${config.model}:${task}:${trimmed}`;
  if (promptResponseCache.has(cacheKey)) {
    return { text: promptResponseCache.get(cacheKey)!, source: 'gemma-4-cache' };
  }

  if (!config.enabled || !config.endpointUrl.trim()) {
    return { text: formatTextDeterministically(trimmed, task), source: 'local-formatter' };
  }

  const systemInstruction =
    task === 'bio'
      ? 'Rewrite this student bio to be concise, factual, and professional (max 2 sentences). Do not invent achievements. Return only the bio:'
      : 'Polish this portfolio item description to be clear, concise, and factual (max 2 sentences). Do not exaggerate. Return only the text:';

  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (config.sessionApiKey.trim()) {
      headers['Authorization'] = `Bearer ${config.sessionApiKey.trim()}`;
    }

    const response = await fetch(config.endpointUrl.trim(), {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: config.model,
        messages: [
          { role: 'system', content: systemInstruction },
          { role: 'user', content: trimmed.slice(0, 500) },
        ],
        max_tokens: 120,
        temperature: 0.2,
      }),
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const reply =
      data?.choices?.[0]?.message?.content?.trim() ||
      data?.response?.trim() ||
      formatTextDeterministically(trimmed, task);

    promptResponseCache.set(cacheKey, reply);
    return { text: reply, source: 'gemma-4-live' };
  } catch {
    return { text: formatTextDeterministically(trimmed, task), source: 'local-formatter' };
  }
}
